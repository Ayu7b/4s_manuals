



<!-- analytics code -->              
<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-30506707-1']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();
</script>
<!-- Einde analytics code -->

<script language="Javascript" type="text/javascript"> 
 
 if (top.location!= self.location) { 
  top.location = self.location.href
 } 
 
</script>

<footer>
<h3>Over ons:</h3>
<p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Quia ipsa sapiente unde praesentium eos dicta porro dignissimos necessitatibus voluptatibus blanditiis, excepturi, facere quisquam error ipsam, deserunt facilis impedit libero quibusdam!</p>
<h3>Contact gegevens:</h3>
<h5>Telefoonnummer:</h5> <p>076-2983220</p>
<h5>Email:</h5> <p>4s@manuals.com</p>
<h5>Social links:</h5>
<p><a href="https://www.facebook.com/">
<img src="img/facebook.jpg" alt="facebook.com" width="50" height="50">
</a></p> <p><a href="https://www.instagram.com/">
<img src="img/instagram.jpg" alt="instagram.com" width="50" height="50">
</a></p>
	© {{ __('misc.copyright') }}
</footer>