<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->yieldContent('head'); ?>
</head>
<body>

<?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
    <div class="row">

        <div class="col-md-8">
            <?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <ul class="breadcrumb">
                <li><a href="/" title="<?php echo e(__('misc.home_alt')); ?>"
                       alt="<?php echo e(__('misc.home_alt')); ?>"><?php echo e(__('misc.home')); ?></a></li>
                <?php echo $__env->yieldContent('breadcrumb'); ?>
            </ul>

            <?php if( isset($_GET['q']) ): ?>
                <?php echo $__env->make('includes.search_results', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php else: ?>
                <?php echo $__env->yieldContent('content'); ?>
            <?php endif; ?>

            <ul class="breadcrumb">
                <li>
					<a href="/" title="<?php echo e(__('misc.home_alt')); ?>" alt="<?php echo e(__('misc.home_alt')); ?>"><?php echo e(__('misc.home')); ?></a>
				</li>
                <?php echo $__env->yieldContent('breadcrumb'); ?>
            </ul>
            
        </div>
    

    </div>


</div>

<!-- Bootstrap core JavaScript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>//window.jQuery || document.write('<script src="../../assets/js/vendor/jquery.min.js"><\/script>')</script>
<script src="<?php echo e(asset('/js/app.js')); ?>"></script>

<div class="footer">
    <div class="row">
        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

</body>
</html>
<?php /**PATH C:\laragon\www\4s_manuals\resources\views/layouts/default.blade.php ENDPATH**/ ?>