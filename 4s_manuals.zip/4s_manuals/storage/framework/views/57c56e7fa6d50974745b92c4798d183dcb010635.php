

<?php $__env->startSection('introduction_text'); ?>
    <div class="introduction_home">
        <p><img src="/img/logo.png" align="right" width="100" height="100"><?php echo e(__('introduction_texts.homepage_line_1')); ?></p>
        <p><?php echo e(__('introduction_texts.homepage_line_2')); ?></p>
        <p><?php echo e(__('introduction_texts.homepage_line_3')); ?></p>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(session('status')): ?>
    <h6 class="alert alert-success"><i class="fa-solid fa-check"></i> <?php echo e(session('status')); ?></h6>
<?php endif; ?>
<div class="brands_title">
    <h1>
        <?php $__env->startSection('populair_brands'); ?>
            <?php echo e(__('misc.populairs_brands')); ?>

        <?php echo $__env->yieldSection(); ?>
        
    </h1>
</div>
<div class="populairTypes">
    <?php $__currentLoopData = $populairs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $populair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p><?php echo e($populair->name); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
    <div class="brands_title">
        <h1>
            <?php $__env->startSection('title'); ?>
                <?php echo e(__('misc.all_brands')); ?>

            <?php echo $__env->yieldSection(); ?>
            
        </h1>
    </div>


    <?php
    $size = count($brands);
    $columns = 3;
    $chunk_size = ceil($size / $columns);
    ?>

    <div class="container">
        <!-- Example row of columns -->
        <div class="row">

            <?php $__currentLoopData = $brands->chunk($chunk_size); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="background_list">
                        <ul>
                            <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <?php
                                $current_first_letter = strtoupper(substr($brand->name, 0, 1));

                                if (!isset($header_first_letter) || (isset($header_first_letter) && $current_first_letter != $header_first_letter)) {
                                    echo '</ul>
                            <h2>' . $current_first_letter . '</h2>
                            <ul>';
                                }
                                $header_first_letter = $current_first_letter
                                ?>

                                <li>
                                    <a href="/<?php echo e($brand->id); ?>/<?php echo e($brand->name_url_encoded); ?>/"><?php echo e($brand->name); ?></a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>

                </div>
                <?php
                unset($header_first_letter);
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\4s_manuals\resources\views/pages/homepage.blade.php ENDPATH**/ ?>