
<meta charset="utf-8">
<meta name="description" content="Download your manual: Free user guides for all brands and devices!"/>
<meta name="author" content="Avarix">
<meta name="keywords" content="userguide, user's guide, guide, manual, manual, owners manual, referenceguide, quickguide, service manual, free, pdf, download"/>
<meta name="language" content="en">
<meta name="google-site-verification" content="Fdb3h6i9VSbRysXMwdteA4E2tZnedlygCcIyJBADqKo" />

<link href="{{ asset('/css/app.css') }}" rel="stylesheet">

<title>Download your manual: Free user guides for all brands and devices!</title>
