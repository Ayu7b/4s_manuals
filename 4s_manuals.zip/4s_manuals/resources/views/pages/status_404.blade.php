@extends('layouts.default')
@section('content')

{{ __('messages.page_not_found') }}

@stop