@extends('layouts.default')

@section('introduction_text')
    <p><img src="img/logo.png" align="right" width="100" height="100">{{ __('introduction_texts.homepage_line_1') }}</p>
    <p>{{ __('introduction_texts.homepage_line_2') }}</p>
    <p>{{ __('introduction_texts.homepage_line_3') }}</p>
@endsection

@section('content')

<h1>Link toevoegen</h1>
<div class="form_layout">
    <form action="/addManuel" method="POST">
       @csrf
        <div class="mb-3">
            <label for="brand">Merk:</label>
            <select name="brand" id="brand" class="selection">
                 @foreach($brands as $brand)
                 <option value="{{$brand->name}}">{{$brand->name}}</option>
                 @endforeach
            </select>
        </div>
        

        <div class="mb-3">
            <label for="type">Type:</label>
            <select name="brand" id="brand" class="selection">
                @foreach($types as $type)
                 <option value="{{$type->id}}">{{$type->name}}</option>
                 @endforeach
            </select>
        </div>

        <div class="mb-3">
            <label for="link">handleiding link:</label>
            <input type="url" name="link" id="link" class="form_input">
        </div>

        <div class="mb-3">
            <label for="filesize">filesize:</label>
            <input type="text" name="filesize" id="filesize" class="form_input">
        </div>

        <div class="mb-3">
            <label for="filename">filename:</label>
            <input type="text" name="filename" id="filename" class="form_input">
        </div>

        <div class="mb-3">
            <label for="DS">Download server:</label>
            <input type="text" name="DS" id="DS" class="form_input">
        </div>


        
        <input type="submit" value="Opslaan" class="success"> 
    </form>
    <!-- <a href="index.php"><input type="submit" value="cancel"></a> -->
</div>

@endsection


