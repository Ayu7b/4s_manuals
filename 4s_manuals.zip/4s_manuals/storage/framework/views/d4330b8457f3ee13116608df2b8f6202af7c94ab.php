

<?php $__env->startSection('breadcrumb'); ?>
	<li><a href="/<?php echo e($brand->id); ?>/<?php echo e($brand->name_url_encoded); ?>/" alt="Manuals for '<?php echo e($brand->name); ?>'" title="Manuals for '<?php echo e($brand->name); ?>'"><?php echo e($brand->name); ?></a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1><?php echo e($brand->name); ?></h1>

<p><?php echo e(__('introduction_texts.type_list', ['brand'=>$brand->name])); ?></p>

    <div class="container">
		<ul>
		<?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li>
				<a href="/<?php echo e($brand->id); ?>/<?php echo e($brand->name_url_encoded); ?>/<?php echo e($type->id); ?>/<?php echo e($type->name_url_encoded); ?>/"><?php echo e($type->name); ?></a>
			</li>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\4s_manuals\resources\views/pages/type_list.blade.php ENDPATH**/ ?>