<?php

namespace App\Http\Controllers;

use App\Models\Brand;
use App\Models\Manual;
use App\Models\Type;
use App\Model\Manuels;
use Illuminate\Http\Request;






class AdminController extends Controller
{



        public function ShowManuels(Type $type_id){

            $types = Type::findOrFail($type_id);



            return view('pages.adminpage', [
                "types" => $types,
            ]);

        }
    public function destroy($type)
    {
    $type = Type::find($type)->delete();
        return redirect('/adminpage')->with('status', 'Handleiding succesvol verwijderd');

    }

    }
//
//$brand = Brand::findOrFail($brand_id);
//$types = Type::where('brand_id', $brand_id)->orderBy('name')->get();
//
//
//
//Brand::updateTotalViews($brand);
//
//return view('pages/type_list', [
//    "types"=>$types,
//    "brand"=>$brand
//]);

