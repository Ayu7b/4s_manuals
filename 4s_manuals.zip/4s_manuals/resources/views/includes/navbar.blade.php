<nav class="navbar navbar-expand navbar-dark bg-dark">
    <div class="container">
        <div class="navbar-header mr-auto">
            <a class="navbar-brand" href="/" title="{{ __('misc.home_alt') }}">{{ __('misc.homepage_title') }}</a>
            <a class="navbar-brand" href="/contact">Contact</a>
            <a class="navbar-brand" href="/add_manual">Handleiding toevoegen</a>
            <a class="navbar-brand" href="/adminpage">Admin</a>
        </div>
        <div id="navbar" class="form-inline">

            <script>
                (function () {
                    var cx = 'partner-pub-6236044096491918:8149652050';
                    var gcse = document.createElement('script');
                    gcse.type = 'text/javascript';
                    gcse.async = true;
                    gcse.src = 'https://cse.google.com/cse.js?cx=' + cx;
                    var s = document.getElementsByTagName('script')[0];
                    s.parentNode.insertBefore(gcse, s);
                })();
            </script>
            <gcse:searchbox-only></gcse:searchbox-only>


        </div><!--/.navbar-collapse -->
    </div>

    <img style="max-width: 25px" src="/img/moon.png" alt="dark-light mode" id="icon">
    <script>
        var icon = document.getElementById("icon");
        icon.onclick = function(){
            document.body.classList.toggle("dark-mode");
            if(document.body.classList.contains("dark-mode")){
              icon.src = "/img/sun.png";
            }else{
                icon.src = "/img/moon.png";
            }
        }
    </script>
</nav>
