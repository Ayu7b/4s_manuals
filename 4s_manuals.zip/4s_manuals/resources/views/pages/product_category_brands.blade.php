@extends('pages.homepage')

@section(
	'title', 'Bijna alle merken...'
)