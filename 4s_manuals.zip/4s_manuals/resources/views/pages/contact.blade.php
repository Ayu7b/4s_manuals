@extends('layouts.default')

@section('introduction_text')
    <p><img src="img/afbl_logo.png" align="right" width="100" height="100">{{ __('introduction_texts.homepage_line_1') }}</p>
    <p>{{ __('introduction_texts.homepage_line_2') }}</p>
    <p>{{ __('introduction_texts.homepage_line_3') }}</p>
@endsection

@section('content')

<h1>Contact Us</h1>
<form action="{{ route('contact') }}" method="POST">
 
    <div class="mb-3">
        <label for="name_input">Naam</label>
        <input type="text" required maxlength="50" id="name_input" name="name" placeholder="Bart Roos">
    </div>
    <div class="mb-3 row">
        <div class="col">
            <label for="email_input">Email:</label>
            <input type="email" required maxlength="50"  id="email_input" name="email"
                placeholder="bart@curio.nl">
        </div>
        <div class="col">
            <label for="phone_input">Telefoonnummer</label>
            <input type="number" required maxlength="15" id="phone_input" name="Phone"
                placeholder="0634567890">
        </div>
    </div>
    <div class="mb-3">
        <label for="message_input">Bericht:</label>
        <textarea class="form-control" id="message_input" name="message" rows="3"></textarea>
    </div>

    <button type="submit" class="btn btn-primary px-4">Versturen</button>
</form>

@endsection


