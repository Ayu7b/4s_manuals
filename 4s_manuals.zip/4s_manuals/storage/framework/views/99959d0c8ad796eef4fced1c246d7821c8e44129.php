

<?php $__env->startSection('introduction_text'); ?>
    <p><img src="img/logo.png" align="right" width="100" height="100"><?php echo e(__('introduction_texts.homepage_line_1')); ?></p>
    <p><?php echo e(__('introduction_texts.homepage_line_2')); ?></p>
    <p><?php echo e(__('introduction_texts.homepage_line_3')); ?></p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1>Link toevoegen</h1>
<div class="form_layout">
    <form action="/addManuel" method="POST">
       <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="brand">Merk:</label>
            <select name="brand" id="brand" class="selection">
                 <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($brand->name); ?>"><?php echo e($brand->name); ?></option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        

        <div class="mb-3">
            <label for="type">Type:</label>
            <select name="brand" id="brand" class="selection">
                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($type->id); ?>"><?php echo e($type->name); ?></option>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="link">handleiding link:</label>
            <input type="url" name="link" id="link" class="form_input">
        </div>

        <div class="mb-3">
            <label for="filesize">filesize:</label>
            <input type="text" name="filesize" id="filesize" class="form_input">
        </div>

        <div class="mb-3">
            <label for="filename">filename:</label>
            <input type="text" name="filename" id="filename" class="form_input">
        </div>

        <div class="mb-3">
            <label for="DS">Download server:</label>
            <input type="text" name="DS" id="DS" class="form_input">
        </div>


        
        <input type="submit" value="Opslaan" class="success"> 
    </form>
    <!-- <a href="index.php"><input type="submit" value="cancel"></a> -->
</div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\4s_manuals\resources\views/pages/add_manual.blade.php ENDPATH**/ ?>