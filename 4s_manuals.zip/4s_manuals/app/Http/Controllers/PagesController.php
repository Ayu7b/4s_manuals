<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Brand;
use App\Models\Manual;
use App\Models\Type;
use App\Model\Manuels;


class PagesController extends Controller
{
    public function homePage(){
        $populairs = DB::table('types')->orderBy('totalView', 'DESC')->get();
        return view('pages.homepage')->with('populairs', $populairs);
    }

    public function add_manual(){
        $brands = DB::table('brands')->get();
        $types = DB::table('types')->get();
        return view('pages.add_manual')->with('brands', $brands)->with('types', $types);
    }


}